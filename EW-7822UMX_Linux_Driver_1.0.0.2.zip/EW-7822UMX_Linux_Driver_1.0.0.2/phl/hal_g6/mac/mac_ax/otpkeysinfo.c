#include "otpkeysinfo.h"

u8 otp_key_info_externalPN[OTP_KEY_INFO_NUM] = {0x0, 0x0};
u8 otp_key_info_customer[OTP_KEY_INFO_NUM]   = {0x0, 0x1};
u8 otp_key_info_serialNum[OTP_KEY_INFO_NUM]  = {0x0, 0x1};

u32 otp_key_info_keyID[OTP_KEY_INFO_NUM] = {0x0, 0x1};
